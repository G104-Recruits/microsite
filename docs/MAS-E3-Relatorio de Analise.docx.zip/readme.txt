Link para o protótipo:
https://www.figma.com/file/E9tT3gA1ITBCDN545vNFVQ/RECRUITS?node-id=43%3A468

Link apresentação do protótipo:
https://g104-recruits.github.io/microsite/docs/Apresentacao-Prototipo.mp4